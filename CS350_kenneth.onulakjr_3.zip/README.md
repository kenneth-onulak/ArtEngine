# Bounding Volumes

- Kenneth Onulak Jr.
- kenneth.onulakjr@digipen.edu
- CS350S23A Project 3
- Hours Spent - 21

### Installing Dependencies:
#### vcpkg
Follow the instructions at https://docs.microsoft.com/en-us/cpp/build/vcpkg?view=msvc-160#installation to clone the vcpkg repository.

Make sure to follow the integration instructions at https://docs.microsoft.com/en-us/cpp/build/vcpkg?view=msvc-160#installation on a per-user basis so that include paths are resolved automagically.

The following packages need to be installed to compile.
#### SDL2
    ./vcpkg install sdl2:x64-windows
    ./vcpkg install sdl2-image:x64-windows
    ./vcpkg install sdl2-ttf:x64-windows
    ./vcpkg install sdl2-mixer:x64-windows

#### GLEW 
    ./vcpkg install glew:x64-windows

#### GLM 
    ./vcpkg install glm:x64-windows

#### Boost Filesystem
    ./vcpkg install boost-filesystem:x64-windows

#### Libnoise
    ./vcpkg install libnoise:x64-windows

#### Freetype
    ./vcpkg install freetype:x64-windows

### Build:
NOTE: You must set `-DCMAKE_TOOLCHAIN_FILE` for vcpkg. Such as the following where you just need to change `{PATH TO VCPKG}` to match your local vcpkg directory.
```
-DCMAKE_TOOLCHAIN_FILE={PATH TO VCPKG}/scripts/buildsystems/vcpkg.cmake
```
- Built using C++ 20
- Compiled with MSVC CMake in CLion on Windows

### How to Use:
Automatically loads models from power plant section text files
- Expects the following file structure to automatically load files
- NOTE: Missing ppsection(s) folder(s) from submission to omit obj files
```
- examples
    - space_partitioning
        - object
            - ppsection4 // omitted from submission
            - ppsection5 // omitted from submission
            - ppsection6 // omitted from submission
            - Section4.txt
            - Section5.txt
            - Section6.txt
```

### Controls:
- WASD to move / rotate camera around objects
- Shift / Space to rotate the camera up and down
- Esc to toggle the imgui interface

### Directory File Structure:
```
- ArtEngine
    - examples // project files
        - space_partitioning
            - object
                - ppsection(s)
                - Section#.txt
            - shader
                - default.fs / cs
            - ... // other project files
    - include
        - ... // all engine source files
```

### Implementation
Parts Completed  
- Scene Creation
- Octree
- BSP Tree
- Interactivity  

### About
Engine is modeled after TinyEngine.